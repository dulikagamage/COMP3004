COMP3004 Assignment 2 🛗
Author: Dulika Gamage 101263208

Files Included:
- DulikaGamage-COMP3004-Assignment2.pdf
  - includes all of the deliverables and diagrams other than the header files.
- header-files (folder)
  - Elevator.h
  - ElevatorControlSystem.h
  - Floor.h
  - GUI.h
  - Passenger.h
